package com.example.languageapp.ui.main;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.example.languageapp.R;
import com.google.android.material.snackbar.Snackbar;
import java.util.ArrayList;


public class StudyActivity extends AppCompatActivity{

    //The ArrayList of Study Words added by the User
    public static ArrayList<String> studyWords = new ArrayList<>();

    ArrayAdapter<String> arrayAdapter;

    //Checks if studyWords has any duplicate words
    public static boolean hasDuplicate(String word) {
        for (String w : studyWords) {
            if (w.equals(word)) {
                return true;
            }
        }
        return false;
    }

    //Removes words that the User chooses
    public void removeWord(int wordIndex) {
        Toast.makeText(getApplicationContext(), "Word has been removed", Toast.LENGTH_LONG).show();
        studyWords.remove(wordIndex);
        arrayAdapter.notifyDataSetChanged();
    }

    //Undos the previous word removal from removeWord()
    public void undoWord(int wordIndex, String word) {
        studyWords.add(wordIndex, word);
        arrayAdapter.notifyDataSetChanged();
        Toast.makeText(getApplicationContext(), "Word has been re-added", Toast.LENGTH_LONG).show();
    }



//// When the selected page is opened
    public void onCreate(Bundle saveInstanceState)
    {

        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_study);

        TextView noWords = findViewById(R.id.noWordsView);
        ListView wordsView = findViewById(R.id.studyList);


        //Checks if the list of Study Words is empty
        if (!studyWords.isEmpty()) {

            //If the list is not empty, it displays the list as normal
            noWords.setVisibility(View.INVISIBLE);

            //Creates the adapter to put the StudyWords list into a WordsView list to be seen by the User
            arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, studyWords);

            // Set The Adapter to the WordsView
            wordsView.setAdapter(arrayAdapter);

            // register onClickListener to handle click events on each item
            wordsView.setOnItemClickListener((adapterView, view, Z, l) -> {
                String selectedWord = studyWords.get(Z);

                //Displays a SnackBar to ask the User if they would like to remove the word
                Snackbar removeSnackbar = Snackbar.make(findViewById(R.id.coordinator),
                        "Remove " + selectedWord + "?", Snackbar.LENGTH_LONG);

                //Sets the SnackBar's action to REMOVE selected word
                removeSnackbar.setAction(R.string.removeWord, view1 -> {
                    removeWord(Z);

                    //Displays a SnackBar to ask the User if they would like to undo the previous action
                    Snackbar undoSnackbar = Snackbar.make(findViewById(R.id.coordinator),
                            "Undo " + selectedWord + " removal?", Snackbar.LENGTH_LONG);
                    undoSnackbar.setAction(R.string.undoWord, view2 -> undoWord(Z, selectedWord));

                    //Set the UNDO action color to GREEN
                    undoSnackbar.setActionTextColor(Color.GREEN);
                    undoSnackbar.show();
                });




                //Change the REMOVE action to red
                removeSnackbar.setActionTextColor(Color.RED);
                removeSnackbar.show();

            });
        }

        //If the list is empty, state that there are no words
        else {
            noWords.setVisibility(View.VISIBLE);
        }



    }







}

//Currently unused color changes for snackbar
//                        View undoView = undoSnackbar.getView();
//                        undoView.setBackgroundColor(Color.GREEN);


//Currently unused color changes for snackbar
//                    View removeView = removeSnackbar.getView();
//                    removeView.setBackgroundColor(Color.RED);