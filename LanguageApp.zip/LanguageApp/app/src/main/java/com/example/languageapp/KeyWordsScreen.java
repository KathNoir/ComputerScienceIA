package com.example.languageapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class KeyWordsScreen extends AppCompatActivity {

    //ArrayLists for the words and definitions
    //When the User is in the fragment, the correct dictionaries are
    //   dumped into their two respective Arraylists
    ArrayList<String> dictionaryWords = new ArrayList<>();
    ArrayList<String> dictionaryDefinitions = new ArrayList<>();

    public void onCreate(Bundle saveInstanceState) {

        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_key_words_screen);



        //The view that the User will see to list the dictionary words
        ListView dictionaryView = findViewById(R.id.dictionaryList);


        //Passing the dictionary variables from the correct language to the ArrayLists
        Bundle extras = getIntent().getExtras();
        dictionaryWords = extras.getStringArrayList("words");
        dictionaryDefinitions = extras.getStringArrayList("defs");


        // Create The Adapter with passing ArrayList as 3rd parameter
        ArrayAdapter<String> arrayAdapter =
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, dictionaryWords);

        // Set The Adapter
        dictionaryView.setAdapter(arrayAdapter);


        // register onClickListener to handle click events on each item
        ArrayList<String> finalDictionaryDefinitions = dictionaryDefinitions;
        dictionaryView.setOnItemClickListener((adapterView, view, i, l) -> {
            String selectedWord = finalDictionaryDefinitions.get(i);
            Toast.makeText(getApplicationContext(), "Definition: " + selectedWord, Toast.LENGTH_LONG).show();
        });

    }


}


//

//