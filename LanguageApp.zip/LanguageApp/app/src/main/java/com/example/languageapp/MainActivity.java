package com.example.languageapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.example.languageapp.databinding.ActivityMainBinding;
import com.example.languageapp.ui.main.SectionsPagerAdapter;
import com.example.languageapp.ui.main.StudyActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);



        com.example.languageapp.databinding.ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = binding.viewPager;
        viewPager.setAdapter(sectionsPagerAdapter);
        TabLayout tabs = binding.tabs;
        tabs.setupWithViewPager(viewPager);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(view -> sendStudy());


    }

    //Sends user to the StudyActivity screen
    public void sendStudy() {
        Intent study = new Intent(this, StudyActivity.class);
        startActivity(study);
    }

    //Sends user to the dictionary of the current language tab
    public void sendDictionary() {
        Intent dictionary = new Intent(this, KeyWordsScreen.class);
        startActivity(dictionary);
    }


}