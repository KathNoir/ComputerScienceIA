package com.example.languageapp.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.languageapp.KeyWordsScreen;
import com.example.languageapp.R;
import com.example.languageapp.databinding.FragmentMainBinding;
import com.example.languageapp.dictionary.ChineseDictionary;
import com.example.languageapp.dictionary.JapaneseDictionary;
import com.example.languageapp.dictionary.KoreanDictionary;

public class allFragments {

    public static class KoreanFragment extends Fragment {

        private static final String ARG_SECTION_NUMBER = "section_number";

        private PageViewModel pageViewModel;
        private FragmentMainBinding binding;

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            pageViewModel = new ViewModelProvider(this).get(PageViewModel.class);
            int index = 1;
            if (getArguments() != null) {
                index = getArguments().getInt(ARG_SECTION_NUMBER);
            }
            pageViewModel.setIndex(index);


        }

        @Override
        public View onCreateView(
                @NonNull LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {


            binding = FragmentMainBinding.inflate(inflater, container, false);
            View root = binding.getRoot();

            final TextView textView = binding.sectionLabel;

            Button dict = root.findViewById(R.id.dictionaryButton);
            dict.setOnClickListener(view -> enterKoreanDictionary());

            Button kor_button_1 = root.findViewById(R.id.button);
            Button kor_button_2 = root.findViewById(R.id.button2);
            Button kor_button_3 = root.findViewById(R.id.button3);
            Button kor_button_4 = root.findViewById(R.id.button4);
            Button kor_button_5 = root.findViewById(R.id.button5);
            Button kor_button_6 = root.findViewById(R.id.button6);


            kor_button_1.setOnClickListener(view -> enterArticle(Article.kor_article_1));
            kor_button_2.setOnClickListener(view -> enterArticle(Article.kor_article_2));
            kor_button_3.setOnClickListener(view -> enterArticle(Article.kor_article_3));
            kor_button_4.setOnClickListener(view -> enterArticle(Article.kor_article_4));
            kor_button_5.setOnClickListener(view -> enterArticle(Article.kor_article_5));
            kor_button_6.setOnClickListener(view -> enterArticle(Article.kor_article_6));

            return root;

        }

        @Override
        public void onDestroyView() {
            super.onDestroyView();
            binding = null;
        }

        public void enterArticle(Article artName) {
            // Do something in response to button
            Intent newIntent = new Intent(this.getContext(), ArticleActivity.class);
            newIntent.putExtra("articleText", artName.text);
            newIntent.putExtra("wordCount", String.valueOf(artName.word_count));
            newIntent.putExtra("language", String.valueOf(artName.language));
            newIntent.putExtra("charCount", String.valueOf(artName.character_count));
            startActivity(newIntent);
        }

        public void enterKoreanDictionary() {
            Intent koreanDict = new Intent(this.getContext(), KeyWordsScreen.class);
            koreanDict.putExtra("words", KoreanDictionary.korean_wordsList);
            koreanDict.putExtra("defs", KoreanDictionary.korean_definitionList);
            startActivity(koreanDict);
        }



    }

    public static class JapaneseFragment extends Fragment {

        private static final String ARG_SECTION_NUMBER = "section_number";

        private PageViewModel pageViewModel;
        private FragmentMainBinding binding;


        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            pageViewModel = new ViewModelProvider(this).get(PageViewModel.class);
            int index = 1;
            if (getArguments() != null) {
                index = getArguments().getInt(ARG_SECTION_NUMBER);
            }
            pageViewModel.setIndex(index);
        }

        @Override
        public View onCreateView(
                @NonNull LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {

            binding = FragmentMainBinding.inflate(inflater, container, false);
            View root = binding.getRoot();

            Button dict = root.findViewById(R.id.dictionaryButton);
            dict.setOnClickListener(view -> enterJapaneseDictionary());

            Button jap_button_1 = root.findViewById(R.id.button);
            jap_button_1.setOnClickListener(view -> enterArticle(Article.jap_article_1));

            Button jap_button_2 = root.findViewById(R.id.button2);
            jap_button_2.setOnClickListener(view -> enterArticle(Article.jap_article_2));

            Button jap_button_3 = root.findViewById(R.id.button3);
            jap_button_3.setOnClickListener(view -> enterArticle(Article.jap_article_3));

            Button jap_button_4 = root.findViewById(R.id.button4);
            jap_button_4.setOnClickListener(view -> enterArticle(Article.jap_article_4));

            Button jap_button_5 =  root.findViewById(R.id.button5);
            jap_button_5.setOnClickListener(view -> enterArticle(Article.jap_article_5));

            Button jap_button_6 = root.findViewById(R.id.button6);
            jap_button_6.setOnClickListener(view -> enterArticle(Article.jap_article_6));

            return root;

        }

        @Override
        public void onDestroyView() {
            super.onDestroyView();
            binding = null;
        }

        public void enterArticle(Article artName) {
            // Do something in response to button
            Intent newIntent = new Intent(this.getContext(), ArticleActivity.class);
            newIntent.putExtra("articleText", artName.text);
            newIntent.putExtra("wordCount", String.valueOf(artName.word_count));
            newIntent.putExtra("language", String.valueOf(artName.language));
            newIntent.putExtra("charCount", String.valueOf(artName.character_count));
            startActivity(newIntent);
        }

        public void enterJapaneseDictionary() {
            Intent japaneseDict = new Intent(this.getContext(), KeyWordsScreen.class);
            japaneseDict.putExtra("words", JapaneseDictionary.japanese_wordsList);
            japaneseDict.putExtra("defs", JapaneseDictionary.japanese_definitionList);
            startActivity(japaneseDict);
        }

    }

    public static class ChineseFragment extends Fragment {

        private static final String ARG_SECTION_NUMBER = "section_number";

        private PageViewModel pageViewModel;
        private FragmentMainBinding binding;

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            pageViewModel = new ViewModelProvider(this).get(PageViewModel.class);
            int index = 1;
            if (getArguments() != null) {
                index = getArguments().getInt(ARG_SECTION_NUMBER);
            }
            pageViewModel.setIndex(index);
        }

        @Override
        public View onCreateView(
                @NonNull LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {

            binding = FragmentMainBinding.inflate(inflater, container, false);
            View root = binding.getRoot();

            final TextView textView = binding.sectionLabel;

            Button dict = root.findViewById(R.id.dictionaryButton);
            dict.setOnClickListener(view -> enterChineseDictionary());

            Button chinese_button_1 = root.findViewById(R.id.button);
            chinese_button_1.setOnClickListener(view -> enterArticle(Article.chi_article_1));

            Button chinese_button_2 = root.findViewById(R.id.button2);
            chinese_button_2.setOnClickListener(view -> enterArticle(Article.chi_article_2));

            Button chinese_button_3 = root.findViewById(R.id.button3);
            chinese_button_3.setOnClickListener(view -> enterArticle(Article.chi_article_3));

            Button chinese_button_4 = root.findViewById(R.id.button4);
            chinese_button_4.setOnClickListener(view -> enterArticle(Article.chi_article_4));

            Button chinese_button_5 =  root.findViewById(R.id.button5);
            chinese_button_5.setOnClickListener(view -> enterArticle(Article.chi_article_5));

            Button chinese_button_6 = root.findViewById(R.id.button6);
            chinese_button_6.setOnClickListener(view -> enterArticle(Article.chi_article_6));

            return root;

        }

        @Override
        public void onDestroyView() {
            super.onDestroyView();
            binding = null;
        }

        public void enterArticle(Article artName) {
            // Do something in response to button
            Intent newIntent = new Intent(this.getContext(), ArticleActivity.class);
            newIntent.putExtra("articleText", artName.text);
            newIntent.putExtra("wordCount", String.valueOf(artName.word_count));
            newIntent.putExtra("language", String.valueOf(artName.language));
            newIntent.putExtra("charCount", String.valueOf(artName.character_count));
            startActivity(newIntent);
        }

        public void enterChineseDictionary() {
            Intent chineseDict = new Intent(this.getContext(), KeyWordsScreen.class);
            chineseDict.putExtra("words", ChineseDictionary.chinese_wordsList);
            chineseDict.putExtra("defs", ChineseDictionary.chinese_definitionList);
            startActivity(chineseDict);
        }



    }

}
