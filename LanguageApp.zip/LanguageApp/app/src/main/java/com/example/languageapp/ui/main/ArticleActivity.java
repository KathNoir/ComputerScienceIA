package com.example.languageapp.ui.main;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.languageapp.KeyWordsScreen;
import com.example.languageapp.R;
import com.example.languageapp.dictionary.ChineseDictionary;
import com.example.languageapp.dictionary.JapaneseDictionary;
import com.example.languageapp.dictionary.KoreanDictionary;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.xeoh.android.texthighlighter.TextHighlighter;

import java.util.Locale;

public class ArticleActivity extends AppCompatActivity implements TextToSpeech.OnInitListener {


    TextToSpeech textToSpeech = null;
//////////////////////////////////////
////////      ARTICLE       //////////
//////////////////////////////////////

    public void addWordToStudy(String word) {
        if (StudyActivity.hasDuplicate(word)) {
            Toast addWordToastFailure = Toast.makeText(this, "This word is already added!", Toast.LENGTH_SHORT);
            addWordToastFailure.show();
        }
        else if (word.equals("") || word.equals(" ")) {
            Toast addWordToastNeutral = Toast.makeText(this, "Select a word to add", Toast.LENGTH_SHORT);
            addWordToastNeutral.show();
        }
        else {
            StudyActivity.studyWords.add(word);
            Toast addWordToastSuccess = Toast.makeText(this, "Word was added to study.", Toast.LENGTH_SHORT);
            addWordToastSuccess.show();
        }
    }





    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article);
        TextView articleView = findViewById(R.id.textView);
        Button addStudy = findViewById(R.id.addWordButton);
        TextView wordCountView = findViewById(R.id.wordView);
        TextView charCountView = findViewById(R.id.wordView2);
        FloatingActionButton dictionaryButton = findViewById(R.id.dictionaryButton);
        EditText editText = findViewById(R.id.searchWord);




        Bundle extras = getIntent().getExtras();
        articleView.setText(extras.getString("articleText"));
        wordCountView.setText("Word count: " + extras.getString("wordCount"));
        charCountView.setText("Char count: " + extras.getString("charCount"));
        String currentLang = extras.getString("language");



        Button searchButton = findViewById(R.id.searchButton);
        searchButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                new TextHighlighter()
                        .setBackgroundColor(Color.parseColor("#FFFF00"))
                        .setForegroundColor(Color.GREEN)
                        .addTarget(articleView)
                        .highlight(editText.getText().toString(), TextHighlighter.BASE_MATCHER);
            }
        });

        addStudy.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                addWordToStudy(editText.getText().toString());
            }
        });

        //////////////////////////////////////
        /////////    TEXT TO SPEECH     //////
        //////////////////////////////////////




        textToSpeech = new TextToSpeech(this, this, "com.samsung.SMT");
        ImageButton playTTSButton = findViewById(R.id.playTTSButton);
        ImageButton stopTTSButton = findViewById(R.id.stopTTSButton);


        playTTSButton.setOnClickListener(view -> {

            String toSpeak = editText.getText().toString();
            textToSpeech.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null, "");

        });

        stopTTSButton.setOnClickListener(view -> {
            textToSpeech.stop();
        });




///Dictionary Button OnClick Methods

    if (currentLang.equals("korean")) {
        dictionaryButton.setOnClickListener(view -> {
            enterKoreanDictionary();
        });
    }
        else if (currentLang.equals("japanese")) {
        dictionaryButton.setOnClickListener(view -> {
            enterJapaneseDictionary();
        });
    }
        else if (currentLang.equals("chinese")) {
        dictionaryButton.setOnClickListener(view -> {
            enterChineseDictionary();
        });
    }



    }




    @Override
    public void onInit(int i) {
        Bundle extras = getIntent().getExtras();
        String currentLang = extras.getString("language");


        if (currentLang.equals("korean")) {
            textToSpeech.setLanguage(Locale.KOREAN);
        }
        else if (currentLang.equals("japanese")) {
            textToSpeech.setLanguage(Locale.JAPANESE);
        }
        else if (currentLang.equals("chinese")) {
            textToSpeech.setLanguage(Locale.TRADITIONAL_CHINESE);
        }

        System.out.println("Completed TTS Initialization");
    }


//////////////////////////////////////
/////////    DICTIONARY     //////////
//////////////////////////////////////


    private void enterKoreanDictionary() {
        Intent koreanDict = new Intent(this, KeyWordsScreen.class);
        koreanDict.putExtra("words", KoreanDictionary.korean_wordsList);
        koreanDict.putExtra("defs", KoreanDictionary.korean_definitionList);
        startActivity(koreanDict);
    }
    private void enterJapaneseDictionary() {
        Intent japaneseDict = new Intent(this, KeyWordsScreen.class);
        japaneseDict.putExtra("words", JapaneseDictionary.japanese_wordsList);
        japaneseDict.putExtra("defs", JapaneseDictionary.japanese_definitionList);
        startActivity(japaneseDict);
    }
    private void enterChineseDictionary() {
        Intent chineseDict = new Intent(this, KeyWordsScreen.class);
        chineseDict.putExtra("words", ChineseDictionary.chinese_wordsList);
        chineseDict.putExtra("defs", ChineseDictionary.chinese_definitionList);
        startActivity(chineseDict);
    }


}